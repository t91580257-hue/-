extends CharacterBody3D

var speed := 3.2
var direction := Vector3.ZERO
var change_timer := 0.0

func _ready() -> void:
	var body := MeshInstance3D.new()
	var mesh := CapsuleMesh.new()
	mesh.radius = 0.42
	mesh.height = 1.6
	body.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.55, 0.22, 0.18)
	body.material_override = mat
	body.position.y = 0.8
	add_child(body)
	var col := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.42
	shape.height = 1.7
	col.shape = shape
	col.position.y = 0.85
	add_child(col)

func _physics_process(delta: float) -> void:
	change_timer -= delta
	if change_timer <= 0.0:
		change_timer = randf_range(1.0, 3.0)
		direction = Vector3(randf_range(-1, 1), 0, randf_range(-1, 1)).normalized()
	velocity.x = direction.x * speed
	velocity.z = direction.z * speed
	if not is_on_floor():
		velocity.y -= 20.0 * delta
	else:
		velocity.y = -0.1
	move_and_slide()
