extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const BOT_SCRIPT = preload("res://scripts/bot.gd")

var peer: ENetMultiplayerPeer
var world: Node3D
var actors: Dictionary = {}
var local_player: CharacterBody3D
var ui: CanvasLayer
var status_label: Label
var mode_label: Label
var host_button: Button
var join_button: Button
var solo_button: Button
var address_edit: LineEdit
var port_edit: LineEdit
var bot_count := 4
var next_bot_id := 1000
var game_started := false

func _ready() -> void:
	_build_world()
	_build_ui()
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)

func _build_world() -> void:
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = Sky.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.65, 0.7, 0.78)
	env.ambient_light_energy = 0.8
	env_node.environment = env
	add_child(env_node)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -25, 0)
	sun.light_energy = 1.1
	add_child(sun)

	world = Node3D.new()
	world.name = "World"
	add_child(world)

	var floor_body := StaticBody3D.new()
	floor_body.name = "ArenaFloor"
	var floor_mesh := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(90, 90)
	floor_mesh.mesh = plane
	var floor_mat := StandardMaterial3D.new()
	floor_mat.albedo_color = Color(0.22, 0.29, 0.24)
	floor_mesh.material_override = floor_mat
	floor_body.add_child(floor_mesh)
	var floor_col := CollisionShape3D.new()
	var floor_shape := BoxShape3D.new()
	floor_shape.size = Vector3(90, 0.5, 90)
	floor_col.shape = floor_shape
	floor_col.position.y = -0.25
	floor_body.add_child(floor_col)
	world.add_child(floor_body)

	for i in range(24):
		var obstacle := StaticBody3D.new()
		var sx := randf_range(2.0, 4.5)
		var sy := randf_range(1.5, 3.5)
		var sz := randf_range(2.0, 4.5)
		var box := MeshInstance3D.new()
		var mesh := BoxMesh.new()
		mesh.size = Vector3(sx, sy, sz)
		box.mesh = mesh
		var mat := StandardMaterial3D.new()
		mat.albedo_color = [Color(0.34, 0.37, 0.32), Color(0.39, 0.35, 0.29), Color(0.25, 0.32, 0.31)][i % 3]
		box.material_override = mat
		obstacle.add_child(box)
		var col := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = mesh.size
		col.shape = shape
		obstacle.add_child(col)
		obstacle.position = Vector3(randf_range(-35, 35), sy / 2.0, randf_range(-35, 35))
		world.add_child(obstacle)

func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	var panel := PanelContainer.new()
	panel.position = Vector2(24, 24)
	panel.custom_minimum_size = Vector2(340, 0)
	ui.add_child(panel)
	var layout := VBoxContainer.new()
	layout.add_theme_constant_override("separation", 8)
	panel.add_child(layout)

	var title := Label.new()
	title.text = "FRONTLINE: ONLINE"
	title.add_theme_font_size_override("font_size", 24)
	layout.add_child(title)

	status_label = Label.new()
	status_label.text = "Выбери режим. Если онлайн пустой — играй с ботами."
	layout.add_child(status_label)

	mode_label = Label.new()
	mode_label.text = "Режим: меню"
	layout.add_child(mode_label)

	address_edit = LineEdit.new()
	address_edit.placeholder_text = "IP сервера (например, 127.0.0.1)"
	address_edit.text = "127.0.0.1"
	layout.add_child(address_edit)

	port_edit = LineEdit.new()
	port_edit.placeholder_text = "Порт"
	port_edit.text = "2456"
	layout.add_child(port_edit)

	host_button = Button.new()
	host_button.text = "Создать онлайн-сервер"
	host_button.pressed.connect(_host_game)
	layout.add_child(host_button)

	join_button = Button.new()
	join_button.text = "Подключиться к онлайн"
	join_button.pressed.connect(_join_game)
	layout.add_child(join_button)

	solo_button = Button.new()
	solo_button.text = "Одиночная игра с ботами"
	solo_button.pressed.connect(_start_solo)
	layout.add_child(solo_button)

	var help := Label.new()
	help.text = "Управление: WASD — движение, мышь — обзор,\nЛКМ — импульсный бластер, R — игровая ракета,\nQ — разведывательный БПЛА, Esc — курсор."
	layout.add_child(help)

func _host_game() -> void:
	_stop_network()
	peer = ENetMultiplayerPeer.new()
	var err := peer.create_server(int(port_edit.text), 8)
	if err != OK:
		status_label.text = "Не удалось создать сервер. Запускаю одиночный режим."
		_start_solo()
		return
	multiplayer.multiplayer_peer = peer
	status_label.text = "Сервер создан. Ожидаем игроков..."
	mode_label.text = "Режим: онлайн (хост)"
	_start_match(true)

func _join_game() -> void:
	_stop_network()
	peer = ENetMultiplayerPeer.new()
	var err := peer.create_client(address_edit.text.strip_edges(), int(port_edit.text))
	if err != OK:
		status_label.text = "Не удалось начать подключение. Запускаю одиночный режим."
		_start_solo()
		return
	multiplayer.multiplayer_peer = peer
	status_label.text = "Подключение к серверу..."
	mode_label.text = "Режим: подключение"
	# Если сервер не ответит, connection_failed переключит в одиночный режим.

func _start_solo() -> void:
	_stop_network()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	mode_label.text = "Режим: одиночная игра"
	status_label.text = "Ты играешь один против компьютерных ботов."
	_start_match(false)

func _start_match(is_host: bool) -> void:
	if game_started:
		_clear_actors()
	game_started = true
	var id := multiplayer.get_unique_id()
	_spawn_player(id, true)
	if not is_host:
		_spawn_bots()
	elif multiplayer.is_server():
		_spawn_bots()
		status_label.text = "Онлайн-сервер готов. Боты заполняют пустые места."
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _spawn_player(id: int, is_local: bool) -> void:
	if actors.has(id):
		return
	var p := CharacterBody3D.new()
	p.name = "Player_%s" % id
	p.set_script(PLAYER_SCRIPT)
	p.set_multiplayer_authority(id)
	world.add_child(p)
	p.global_position = Vector3(randf_range(-5, 5), 1.2, randf_range(-5, 5))
	p.is_local_player = is_local
	actors[id] = p
	if is_local:
		local_player = p

func _spawn_bots() -> void:
	for i in range(bot_count):
		var bot := CharacterBody3D.new()
		bot.name = "Bot_%s" % next_bot_id
		bot.set_script(BOT_SCRIPT)
		world.add_child(bot)
		bot.global_position = Vector3(randf_range(-25, 25), 1.2, randf_range(-25, 25))
		actors[next_bot_id] = bot
		next_bot_id += 1

func _clear_actors() -> void:
	for actor in actors.values():
		if is_instance_valid(actor):
			actor.queue_free()
	actors.clear()
	local_player = null

func _stop_network() -> void:
	if peer != null:
		peer.close()
		peer = null
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()

func _on_peer_connected(id: int) -> void:
	status_label.text = "Игрок подключился: %s" % id
	if multiplayer.is_server():
		_spawn_player_rpc.rpc(id, false)

@rpc("authority", "call_local", "reliable")
func _spawn_player_rpc(id: int, is_local: bool) -> void:
	_spawn_player(id, is_local)

func _on_peer_disconnected(id: int) -> void:
	if actors.has(id):
		actors[id].queue_free()
		actors.erase(id)
	status_label.text = "Игрок отключился: %s" % id
	if multiplayer.is_server() and actors.size() <= 1:
		status_label.text += " — боты остаются в матче."

func _on_connected() -> void:
	status_label.text = "Подключено! Входим в матч."
	mode_label.text = "Режим: онлайн"
	_start_match(false)

func _on_connection_failed() -> void:
	status_label.text = "Сервер недоступен. Переключаю в одиночную игру..."
	_start_solo()

func _on_server_disconnected() -> void:
	status_label.text = "Связь потеряна. Продолжаем с ботами в одиночном режиме."
	_start_solo()

func _process(_delta: float) -> void:
	# Автоматический fallback: если попытка соединения не состоялась,
	# connection_failed переводит игру в solo. В режиме хоста боты уже есть.
	pass

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
