extends CharacterBody3D

var is_local_player := false
var speed := 7.0
var gravity := 20.0
var look_sensitivity := 0.0025
var camera_pivot: Node3D
var camera: Camera3D
var cooldown := 0.0
var rocket_cooldown := 0.0
var drone_cooldown := 0.0
var health := 100

func _ready() -> void:
	_build_character()
	if is_local_player:
		camera.current = true
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _build_character() -> void:
	var body_mesh := MeshInstance3D.new()
	var capsule := CapsuleMesh.new()
	capsule.radius = 0.42
	capsule.height = 1.6
	body_mesh.mesh = capsule
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.24, 0.34, 0.27)
	body_mesh.material_override = mat
	body_mesh.position.y = 0.8
	add_child(body_mesh)

	var col := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.42
	shape.height = 1.7
	col.shape = shape
	col.position.y = 0.85
	add_child(col)

	camera_pivot = Node3D.new()
	camera_pivot.position.y = 1.45
	add_child(camera_pivot)
	camera = Camera3D.new()
	camera.position = Vector3(0, 0.1, 0)
	camera_pivot.add_child(camera)
	camera.current = false

func _unhandled_input(event: InputEvent) -> void:
	if not is_local_player:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * look_sensitivity)
		camera_pivot.rotate_x(-event.relative.y * look_sensitivity)
		camera_pivot.rotation.x = clamp(camera_pivot.rotation.x, -1.35, 1.35)
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			_fire_arcade_bolt()
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_R:
			_launch_game_rocket()
		elif event.keycode == KEY_Q:
			_send_recon_drone()

func _physics_process(delta: float) -> void:
	cooldown = maxf(0.0, cooldown - delta)
	rocket_cooldown = maxf(0.0, rocket_cooldown - delta)
	drone_cooldown = maxf(0.0, drone_cooldown - delta)
	if not is_local_player:
		return
	var input_dir := Vector2.ZERO
	input_dir.x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
	input_dir.y = Input.get_action_strength("move_backward") - Input.get_action_strength("move_forward")
	if Input.is_key_pressed(KEY_W): input_dir.y -= 1.0
	if Input.is_key_pressed(KEY_S): input_dir.y += 1.0
	if Input.is_key_pressed(KEY_A): input_dir.x -= 1.0
	if Input.is_key_pressed(KEY_D): input_dir.x += 1.0
	input_dir = input_dir.normalized()
	var direction := (global_transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	velocity.x = direction.x * speed
	velocity.z = direction.z * speed
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = -0.1
	if Input.is_key_pressed(KEY_SPACE) and is_on_floor():
		velocity.y = 7.0
	move_and_slide()

func _fire_arcade_bolt() -> void:
	if cooldown > 0.0: return
	cooldown = 0.22
	_spawn_projectile(18.0, Color(0.25, 0.8, 1.0), 0.16)

func _launch_game_rocket() -> void:
	if rocket_cooldown > 0.0: return
	rocket_cooldown = 2.5
	# Stylized in-game rocket projectile; deliberately arcade-like, not a real-world model.
	_spawn_projectile(11.0, Color(1.0, 0.45, 0.12), 0.32)

func _spawn_projectile(projectile_speed: float, tint: Color, radius: float) -> void:
	var projectile := Area3D.new()
	var sphere := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	sphere.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = tint
	mat.emission_enabled = true
	mat.emission = tint
	sphere.material_override = mat
	projectile.add_child(sphere)
	var shape_node := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = radius
	shape_node.shape = shape
	projectile.add_child(shape_node)
	get_tree().current_scene.add_child(projectile)
	projectile.global_position = camera.global_position + (-camera.global_transform.basis.z * 1.2)
	var direction := -camera.global_transform.basis.z
	var timer := get_tree().create_timer(2.0)
	projectile.set_meta("direction", direction)
	projectile.set_meta("speed", projectile_speed)
	projectile.set_meta("born", Time.get_ticks_msec())
	projectile.set_script(load("res://scripts/projectile.gd"))
	timer.timeout.connect(func(): if is_instance_valid(projectile): projectile.queue_free())

func _send_recon_drone() -> void:
	if drone_cooldown > 0.0: return
	drone_cooldown = 12.0
	var drone := Node3D.new()
	var mesh_instance := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.28
	mesh.height = 0.18
	mesh_instance.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.2, 0.85, 0.95)
	material.emission_enabled = true
	material.emission = Color(0.1, 0.6, 0.8)
	mesh_instance.material_override = material
	drone.add_child(mesh_instance)
	get_tree().current_scene.add_child(drone)
	drone.global_position = global_position + Vector3(0, 4, 0)
	var label := Label3D.new()
	label.text = "РАЗВЕДКА: ОБЗОР"
	label.font_size = 32
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	drone.add_child(label)
	var tween := create_tween()
	tween.tween_property(drone, "position", drone.position + Vector3(0, 10, 0), 1.0)
	tween.tween_interval(4.0)
	tween.tween_callback(drone.queue_free)
	# Brief scan pulse shown as a visible ring around the player.
	var ring := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 5.0
	torus.outer_radius = 5.15
	ring.mesh = torus
	var ring_mat := StandardMaterial3D.new()
	ring_mat.albedo_color = Color(0.1, 0.8, 1.0, 0.65)
	ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ring.material_override = ring_mat
	get_tree().current_scene.add_child(ring)
	ring.global_position = global_position + Vector3.UP * 0.1
	var scan_tween := create_tween()
	scan_tween.tween_property(ring, "scale", Vector3.ONE * 5.0, 1.0)
	scan_tween.tween_callback(ring.queue_free)
