extends Area3D

var direction := Vector3.FORWARD
var speed := 12.0

func _ready() -> void:
	direction = get_meta("direction", Vector3.FORWARD)
	speed = float(get_meta("speed", 12.0))

func _process(delta: float) -> void:
	global_position += direction * speed * delta
